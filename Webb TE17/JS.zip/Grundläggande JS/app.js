// Element

// Hämtar ett element med ett ID och sparar i en konstant variabel(kan ej ändras senare)
const rubrikText = document.getElementById("rubrik");

// Här använder vi queryselector som är som getElementByID fast vi använder CSS syntax för att hämta värden
const knapp = document.querySelector('#knapp');


// Event listeners

// knapp.addEventListener('click', function() {
//     rubrikText.textContent = 'Halloj';
//     rubrikText.style.color = 'red';
// });

// Lägger till en event-listener som lyssnar efter ett click, kör metoden/funktionen "change" vid knapptryck
knapp.addEventListener('click', change);


// Allt annat

var red = false; // Global variabel som håller ett bool värde

// Här skapar vi en funktion med namnet change, parenteserna används för att ta indata
function change() {

    // Början på vår if-sats. Tar in ett argument, om argumentet är sant körs koden direkt nedanför
    if (confirm('Röd?')) {
        rubrikText.textContent = 'Halloj';
        rubrikText.style.color = 'red';
        red = false;

    } else {    // Annars körs denna kod
        rubrikText.textContent = 'Hejdå';   // Här ändrar vi textinnehållet i vår rubrik(h1)
        rubrikText.style.color = 'black';   // Här ändrar vi färg med hjälp av style-egenskapen
        red = true;                         // Sätter red till true
    }
    
}
